PPA_AdaPath_NPU_WM (자유주제: WM-811K 웨이퍼맵 결함 4-class, 모델 B)  -  Pin_Pineapple_Applepen(PPA) / 경북대 IDEC 2026 창의 회로설계 챌린지 (디지털)

[구성]
  PPA_AdaPath_NPU_WM.xpr  Vivado 2023.1 프로젝트 (모든 경로는 프로젝트 폴더 기준 상대경로)
  src/   설계 소스. 최상위 모듈 chip (chip_adapath.v) - 주최측 레퍼런스 chip 과 포트 목록/폭 동일 (CHIP_N_CLASS = 4)
  sim/   tb_wm.v - 주최측 top_tb 와 같은 방식(이미지마다 리셋 후 1 px/cycle 스트리밍)으로 954장을 순서대로 처리
  data/  wm_input_954.txt (WM-811K 테스트 954장, 주최측 input 과 같은 형식), wm_expect.txt (라벨, 정수 Golden 판정·모드·Score Margin)

[실행]
  Flow > Run Simulation > Run Behavioral Simulation (top = tb_wm). Tcl 콘솔에 정확도, Golden 일치 수, 모드 분포, 클래스별 recall 출력.
  기대 결과: Accuracy 774 / 954 = 81.13 %, Golden match (decision, mode, margin) 954 / 954, Easy/Medium/Hard 404 / 167 / 383.

[가중치]
  학습한 INT8 가중치는 src/adapath_weights.vh 의 상수로 내부 고정. 레퍼런스 가중치 포트는 미사용(0 연결).
