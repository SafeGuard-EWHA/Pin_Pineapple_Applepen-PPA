# 디버그 정보 없이 컴파일한 스냅샷용. 신호 값을 읽지 않고, 진행 시각과 벽시계 시간만 기록한다.
set t0 [clock seconds]
for {set k 1} {$k <= 900} {incr k} {
  run 10 ns
  puts "STEP k=$k wall=[expr {[clock seconds]-$t0}]s"
  flush stdout
  if {[file exists stop.flag]} break
}
puts "TRACE_END"
quit
