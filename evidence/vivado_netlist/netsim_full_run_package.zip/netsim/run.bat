@echo off
rem 설치된 Vivado 중 가장 최신 버전의 bin을 PATH에 추가
for /d %%v in (C:\Xilinx\Vivado\*) do set VB=%%v\bin
set PATH=%VB%;%PATH%
echo Vivado: %VB%
call xvlog.bat 1_synth.v asap7sc7p5t_AO_RVT_TT_201020.v asap7sc7p5t_INVBUF_RVT_TT_201020.v asap7sc7p5t_OA_RVT_TT_201020.v asap7sc7p5t_SEQ_RVT_TT_220101.v asap7sc7p5t_SIMPLE_RVT_TT_201020.v top_tb.v xfill.v > xvlog.out 2>&1
call xelab.bat top_tb_1000 xfill -timescale 1ns/1ps -debug off -s netfast > xelab.out 2>&1
call xsim.bat netfast -tclbatch trace.tcl -log net.log
echo DONE > done.flag
