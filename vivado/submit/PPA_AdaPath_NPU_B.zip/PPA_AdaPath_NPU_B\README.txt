PPA_AdaPath_NPU_B (확장 모델 B: conv2 8ch)  -  Pin_Pineapple_Applepen(PPA) / 경북대 IDEC 2026 창의 회로설계 챌린지 (디지털)

[구성]
  PPA_AdaPath_NPU_B.xpr  Vivado 2023.1 프로젝트 (모든 경로는 프로젝트 폴더 기준 상대경로)
  src/   설계 소스. 최상위 모듈 chip (chip_adapath.v) - 주최측 레퍼런스 chip 과 포트 목록/폭 동일
  sim/   top_tb.v - 주최측 테스트벤치 원본에서 데이터 파일 경로만 파일명으로 변경
         (시뮬레이션 top: top_tb_1000)
  data/  input_1000.txt 및 주최측 가중치 파일 (시뮬레이션 실행 시 자동으로 복사됨)

[평가 방법]
  data/input_1000.txt 를 같은 형식의 hidden 파일로 교체한 뒤
  Flow > Run Simulation > Run Behavioral Simulation 을 실행하면 Tcl 콘솔에 정확도가 출력됩니다.

[가중치]
  레퍼런스 가중치 포트(w_11 ... b_fc)는 입력으로만 받고 사용하지 않습니다.
  본 팀이 학습한 INT8 가중치는 src/adapath_weights.vh 의 상수로 회로 내부에 고정되어 있습니다.
